<?php

namespace Modules\ParentModule\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use Modules\ParentModule\Models\ParentModel;
use App\Models\User;

class ImpersonationController extends Controller
{
    /**
     * Login as a child (impersonate)
     *
     * @param Request $request
     * @param int $childId
     * @return \Illuminate\Http\RedirectResponse
     */
    public function loginAsChild(Request $request, $childId)
    {
        try {
            // Get the current parent user
            $parentUser = Auth::user();
            
            // Get the parent model
            $parent = ParentModel::where('user_id', $parentUser->id)->first();
            
            if (!$parent) {
                return redirect()->back()->with('error', 'Parent account not found.');
            }
            
            // Check if the child belongs to this parent
            $child = $parent->children()->where('users.id', $childId)->first();
            
            if (!$child) {
                return redirect()->back()->with('error', 'You do not have permission to access this child account.');
            }
            
            // Store the parent's user ID in session for later restoration
            Session::put('impersonating_parent_id', $parentUser->id);
            Session::put('impersonating_parent_name', $parentUser->name);
            Session::put('is_impersonating', true);
            
            // Log the impersonation for security audit
            Log::info('Parent impersonation started', [
                'parent_id' => $parentUser->id,
                'parent_name' => $parentUser->name,
                'child_id' => $childId,
                'child_name' => $child->name,
                'ip_address' => $request->ip(),
                'timestamp' => now()
            ]);
            
            // Login as the child
            Auth::login($child);
            
            // Regenerate session for security
            $request->session()->regenerate();
            
            return redirect()->route('dashboard')->with('info', 'You are now logged in as ' . $child->name . '. Click "Back to Parent Dashboard" to return.');
            
        } catch (\Exception $e) {
            Log::error('Impersonation failed', [
                'error' => $e->getMessage(),
                'parent_id' => Auth::id(),
                'child_id' => $childId
            ]);
            
            return redirect()->back()->with('error', 'Failed to login as child. Please try again.');
        }
    }
    
    /**
     * Return to parent dashboard (stop impersonation)
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function returnToParent(Request $request)
    {
        try {
            // Check if currently impersonating
            if (!Session::has('impersonating_parent_id')) {
                return redirect()->route('parent.dashboard')->with('warning', 'You are not currently impersonating a child.');
            }
            
            // Get the parent user ID from session
            $parentUserId = Session::get('impersonating_parent_id');
            $currentChildId = Auth::id();
            $currentChildName = Auth::user()->name;
            
            // Find the parent user
            $parentUser = User::find($parentUserId);
            
            if (!$parentUser) {
                // Clear session if parent not found
                Session::forget(['impersonating_parent_id', 'impersonating_parent_name', 'is_impersonating']);
                return redirect()->route('login')->with('error', 'Parent account not found. Please login again.');
            }
            
            // Log the return for security audit
            Log::info('Parent impersonation ended', [
                'parent_id' => $parentUserId,
                'parent_name' => $parentUser->name,
                'child_id' => $currentChildId,
                'child_name' => $currentChildName,
                'ip_address' => $request->ip(),
                'timestamp' => now()
            ]);
            
            // Clear impersonation session data
            Session::forget(['impersonating_parent_id', 'impersonating_parent_name', 'is_impersonating']);
            
            // Login back as parent
            Auth::login($parentUser);
            
            // Regenerate session for security
            $request->session()->regenerate();
            
            return redirect()->route('parent.dashboard')->with('success', 'Welcome back! You have returned to your parent dashboard.');
            
        } catch (\Exception $e) {
            Log::error('Return to parent failed', [
                'error' => $e->getMessage(),
                'session_parent_id' => Session::get('impersonating_parent_id')
            ]);
            
            return redirect()->back()->with('error', 'Failed to return to parent dashboard. Please try again.');
        }
    }
    
    /**
     * Check if current user is impersonating
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkImpersonation()
    {
        return response()->json([
            'is_impersonating' => Session::get('is_impersonating', false),
            'parent_name' => Session::get('impersonating_parent_name', null)
        ]);
    }
}

