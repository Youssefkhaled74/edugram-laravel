<?php

namespace Modules\ParentModule\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Modules\ParentModule\Models\ParentModel;
use Modules\ParentModule\Models\ParentChild;

class ParentCourseController extends Controller
{
    /**
     * Display all courses for all children.
     */
    public function index()
    {
        try {
            $parent = ParentModel::firstOrCreate(
                ['user_id' => Auth::id()],
                [
                    'is_verified' => false,
                    'status' => 'active',
                    'lms_id' => 1
                ]
            );
            
            $children = $parent->children()->wherePivot('status', 'active')->get();
            
            // Get all enrolled courses for all children
            $allCourses = collect();
            
            if (class_exists('\App\Models\CourseEnrolled')) {
                foreach ($children as $child) {
                    $courses = \App\Models\CourseEnrolled::where('user_id', $child->id)
                        ->with('course')
                        ->get();
                    
                    foreach ($courses as $course) {
                        $course->student_name = $child->name;
                        $course->student_id = $child->id;
                    }
                    
                    $allCourses = $allCourses->merge($courses);
                }
            }
            
            return view('parentmodule::courses.index', compact('parent', 'children', 'allCourses'));
            
        } catch (\Exception $e) {
            return redirect()->route('parent.dashboard')
                ->with('error', 'Failed to load courses: ' . $e->getMessage());
        }
    }

    /**
     * Display courses for a specific child.
     */
    public function childCourses($childId)
    {
        try {
            $parent = ParentModel::firstOrCreate(
                ['user_id' => Auth::id()],
                [
                    'is_verified' => false,
                    'status' => 'active',
                    'lms_id' => 1
                ]
            );
            
            // Verify this child belongs to the parent
            $relationship = ParentChild::where('parent_id', $parent->id)
                ->where('student_id', $childId)
                ->where('status', 'active')
                ->first();
            
            if (!$relationship) {
                return redirect()->route('parent.courses.index')
                    ->with('error', 'Child not found or does not belong to you.');
            }
            
            $child = User::find($childId);
            
            if (!$child) {
                return redirect()->route('parent.courses.index')
                    ->with('error', 'Student not found.');
            }
            
            // Get enrolled courses for this child
            $enrolledCourses = collect();
            $availableCourses = collect();
            
            if (class_exists('\App\Models\CourseEnrolled')) {
                $enrolledCourses = \App\Models\CourseEnrolled::where('user_id', $child->id)
                    ->with('course')
                    ->get();
            }
            
            // Get available courses (not enrolled)
            if (class_exists('\Modules\CourseSetting\Entities\Course')) {
                $enrolledCourseIds = $enrolledCourses->pluck('course_id')->toArray();
                
                $availableCourses = \Modules\CourseSetting\Entities\Course::where('status', 1)
                    ->whereNotIn('id', $enrolledCourseIds)
                    ->get();
            }
            
            return view('parentmodule::courses.child-courses', compact(
                'parent',
                'child',
                'enrolledCourses',
                'availableCourses'
            ));
            
        } catch (\Exception $e) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'Failed to load courses: ' . $e->getMessage());
        }
    }

    /**
     * Show course details.
     */
    public function show($courseId)
    {
        try {
            $parent = ParentModel::firstOrCreate(
                ['user_id' => Auth::id()],
                [
                    'is_verified' => false,
                    'status' => 'active',
                    'lms_id' => 1
                ]
            );
            
            if (!class_exists('\Modules\CourseSetting\Entities\Course')) {
                return redirect()->route('parent.courses.index')
                    ->with('error', 'Course module not available.');
            }
            
            $course = \Modules\CourseSetting\Entities\Course::find($courseId);
            
            if (!$course) {
                return redirect()->route('parent.courses.index')
                    ->with('error', 'Course not found.');
            }
            
            // Get course instructor
            $instructor = null;
            if (isset($course->user_id) && $course->user_id) {
                $instructor = User::find($course->user_id);
            }
            
            // Get parent's children (ACTIVE relationships only)
            $children = $parent->children()
                ->wherePivot('status', 'active')
                ->get();
            
            return view('parentmodule::courses.show', compact('parent', 'course', 'instructor', 'children'));
            
        } catch (\Exception $e) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'Failed to load course details: ' . $e->getMessage());
        }
    }

    /**
     * Enroll a child in a course.
     */
    public function enroll(Request $request)
    {
        $request->validate([
            'course_id' => 'required|integer',
            'student_id' => 'required|integer',
        ]);

        try {
            $parent = ParentModel::firstOrCreate(
                ['user_id' => Auth::id()],
                [
                    'is_verified' => false,
                    'status' => 'active',
                    'lms_id' => 1
                ]
            );
            
            // Verify this child belongs to the parent
            $relationship = ParentChild::where('parent_id', $parent->id)
                ->where('student_id', $request->student_id)
                ->where('status', 'active')
                ->first();
            
            if (!$relationship) {
                return redirect()->back()
                    ->with('error', 'You do not have permission to enroll this student.');
            }
            
            // Check if course exists
            if (!class_exists('\Modules\CourseSetting\Entities\Course')) {
                return redirect()->back()
                    ->with('error', 'Course module not available.');
            }
            
            $course = \Modules\CourseSetting\Entities\Course::find($request->course_id);
            
            if (!$course) {
                return redirect()->back()
                    ->with('error', 'Course not found.');
            }
            
            // Check if already enrolled
            if (class_exists('\App\Models\CourseEnrolled')) {
                $exists = \App\Models\CourseEnrolled::where('user_id', $request->student_id)
                    ->where('course_id', $request->course_id)
                    ->exists();
                
                if ($exists) {
                    return redirect()->back()
                        ->with('error', 'Student is already enrolled in this course.');
                }
                
                // Create enrollment
                \App\Models\CourseEnrolled::create([
                    'user_id' => $request->student_id,
                    'course_id' => $request->course_id,
                    'enrolled_date' => now(),
                    'status' => 1,
                    'lms_id' => 1
                ]);
                
                $student = User::find($request->student_id);
                
                return redirect()->back()
                    ->with('success', $student->name . ' has been enrolled in ' . $course->title . ' successfully!');
            }
            
            return redirect()->back()
                ->with('error', 'Enrollment system not available.');
            
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to enroll student: ' . $e->getMessage());
        }
    }
}
