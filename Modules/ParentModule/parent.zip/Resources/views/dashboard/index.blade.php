@extends('parentmodule::layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Parent Dashboard')
@section('page-subtitle', 'Welcome back, ' . Auth::user()->name)
@section('content')
<div class="container-fluid">
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                My Children
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $childrenCount }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Active Courses
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $activeCourses }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-book fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Pending Payments
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $pendingPayments }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Notifications
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $unreadNotifications }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-bell fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Children Overview -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-user-graduate mr-2"></i>
                        My Children
                    </h6>
                </div>
                <div class="card-body">
                    @if($children->count() > 0)
                        <div class="row">
                            @foreach($children as $child)
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100 border-left-primary">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center mb-3">
                                                <img src="{{ $child->image ?? asset('public/demo/user/user.jpg') }}" 
                                                     alt="{{ $child->name }}" 
                                                     class="rounded-circle mr-3"
                                                     width="60" height="60"
                                                     style="border: 3px solid #667eea;">
                                                <div>
                                                    <h5 class="mb-0">{{ $child->name }}</h5>
                                                    <small class="text-muted">{{ $child->email }}</small>
                                                </div>
                                            </div>
                                            
                                            <div class="row text-center mb-3">
                                                <div class="col-6">
                                                    <div class="p-2 bg-light rounded">
                                                        <h4 class="mb-0 text-primary">{{ $child->enrolled_courses_count }}</h4>
                                                        <small class="text-muted">Courses</small>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="p-2 bg-light rounded">
                                                        <h4 class="mb-0 text-success">
                                                            <span class="badge badge-success">Active</span>
                                                        </h4>
                                                        <small class="text-muted">Status</small>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between">
                                                <a href="{{ route('parent.children.show', $child->id) }}" 
                                                   class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye mr-1"></i>
                                                    View
                                                </a>
                                                <a href="{{ route('parent.courses.child', $child->id) }}" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-book mr-1"></i>
                                                    Courses
                                                </a>
                                                <a href="{{ route('parent.reports.child', $child->id) }}" 
                                                   class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-chart-line mr-1"></i>
                                                    Report
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-user-plus fa-4x mb-3" style="color: #e0e0e0;"></i>
                            <h5 class="text-muted">No Children Added Yet</h5>
                            <p class="text-muted mb-4">Start by adding your children to manage their courses and progress.</p>
                            <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus-circle mr-2"></i>
                                Add Child
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    @if($recentActivities->count() > 0)
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-history mr-2"></i>
                        Recent Activities
                    </h6>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        @foreach($recentActivities as $activity)
                            <div class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <div class="mr-3">
                                        <i class="fas {{ $activity['icon'] }} fa-2x text-{{ $activity['color'] }}"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <strong>{{ $activity['student_name'] }}</strong> enrolled in 
                                        <strong>{{ $activity['course_name'] }}</strong>
                                    </div>
                                    <div class="text-muted">
                                        <small>
                                            @if($activity['date'] instanceof \Carbon\Carbon)
                                                {{ $activity['date']->diffForHumans() }}
                                            @else
                                                {{ \Carbon\Carbon::parse($activity['date'])->diffForHumans() }}
                                            @endif
                                        </small>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<style>
.border-left-primary {
    border-left: 0.25rem solid #667eea !important;
}
.border-left-success {
    border-left: 0.25rem solid #28a745 !important;
}
.border-left-warning {
    border-left: 0.25rem solid #ffc107 !important;
}
.border-left-info {
    border-left: 0.25rem solid #17a2b8 !important;
}
</style>
@endsection
