@extends('parentmodule::layouts.app')

@section('title', 'Add Child')
@section('page-title', 'Add Child')
@section('page-subtitle', 'Register a new student or link existing student')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-user-plus mr-2"></i>
                    Add Child to Your Account
                </div>
                <div class="card-body">
                    @include('parentmodule::partials.alerts')
                    
                    <form method="POST" action="{{ route('parent.children.store') }}">
                        @csrf
                        
                        <!-- Registration Type Selection -->
                        <div class="form-group">
                            <label><strong>Registration Type</strong></label>
                            <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
                                <label class="btn btn-outline-primary active">
                                    <input type="radio" name="registration_type" value="new" checked onchange="toggleRegistrationType()">
                                    <i class="fas fa-user-plus mr-2"></i>
                                    Create New Student Account
                                </label>
                                <label class="btn btn-outline-primary">
                                    <input type="radio" name="registration_type" value="existing" onchange="toggleRegistrationType()">
                                    <i class="fas fa-link mr-2"></i>
                                    Link Existing Student
                                </label>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <!-- New Student Registration Form -->
                        <div id="new-student-form">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-user mr-2"></i>
                                Student Information
                            </h5>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control @error('name') is-invalid @enderror" 
                                               id="name" 
                                               name="name" 
                                               value="{{ old('name') }}"
                                               placeholder="Enter student's full name">
                                        @error('name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email <span class="text-danger">*</span></label>
                                        <input type="email" 
                                               class="form-control @error('email') is-invalid @enderror" 
                                               id="email" 
                                               name="email" 
                                               value="{{ old('email') }}"
                                               placeholder="student@example.com">
                                        @error('email')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="password">Password <span class="text-danger">*</span></label>
                                        <input type="password" 
                                               class="form-control @error('password') is-invalid @enderror" 
                                               id="password" 
                                               name="password" 
                                               placeholder="Minimum 8 characters">
                                        @error('password')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">Phone Number</label>
                                        <input type="text" 
                                               class="form-control @error('phone') is-invalid @enderror" 
                                               id="phone" 
                                               name="phone" 
                                               value="{{ old('phone') }}"
                                               placeholder="Phone number">
                                        @error('phone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="date_of_birth">Date of Birth</label>
                                        <input type="date" 
                                               class="form-control @error('date_of_birth') is-invalid @enderror" 
                                               id="date_of_birth" 
                                               name="date_of_birth" 
                                               value="{{ old('date_of_birth') }}">
                                        @error('date_of_birth')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="gender">Gender</label>
                                        <select class="form-control @error('gender') is-invalid @enderror" 
                                                id="gender" 
                                                name="gender">
                                            <option value="">Select Gender</option>
                                            <option value="male" {{ old('gender') == 'male' ? 'selected' : '' }}>Male</option>
                                            <option value="female" {{ old('gender') == 'female' ? 'selected' : '' }}>Female</option>
                                        </select>
                                        @error('gender')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Existing Student Link Form -->
                        <div id="existing-student-form" style="display: none;">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-link mr-2"></i>
                                Link to Existing Student
                            </h5>
                            
                            <div class="form-group">
                                <label for="student_id">Student Email or ID <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('student_id') is-invalid @enderror" 
                                       id="student_search" 
                                       placeholder="Enter student's email or ID">
                                <input type="hidden" name="student_id" id="student_id">
                                @error('student_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="form-text text-muted">
                                    The student must already have an account in the system.
                                </small>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <!-- Relationship Information -->
                        <h5 class="text-primary mb-3">
                            <i class="fas fa-heart mr-2"></i>
                            Relationship Information
                        </h5>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="relationship_type">Relationship <span class="text-danger">*</span></label>
                                    <select class="form-control @error('relationship_type') is-invalid @enderror" 
                                            id="relationship_type" 
                                            name="relationship_type" 
                                            required>
                                        <option value="">Select Relationship</option>
                                        <option value="father" {{ old('relationship_type') == 'father' ? 'selected' : '' }}>Father</option>
                                        <option value="mother" {{ old('relationship_type') == 'mother' ? 'selected' : '' }}>Mother</option>
                                        <option value="guardian" {{ old('relationship_type') == 'guardian' ? 'selected' : '' }}>Guardian</option>
                                        <option value="other" {{ old('relationship_type') == 'other' ? 'selected' : '' }}>Other</option>
                                    </select>
                                    @error('relationship_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" 
                                               class="custom-control-input" 
                                               id="is_primary_parent" 
                                               name="is_primary_parent" 
                                               value="1"
                                               {{ old('is_primary_parent') ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="is_primary_parent">
                                            I am the primary parent/guardian
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle mr-2"></i>
                            <strong>Note:</strong> The student account will be created immediately and you will have full access to manage their courses, view grades, and make payments.
                        </div>
                        
                        <div class="form-group mb-0">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-check mr-2"></i>
                                Add Child
                            </button>
                            <a href="{{ route('parent.children.index') }}" class="btn btn-secondary btn-lg">
                                <i class="fas fa-times mr-2"></i>
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function toggleRegistrationType() {
    const registrationType = document.querySelector('input[name="registration_type"]:checked').value;
    const newForm = document.getElementById('new-student-form');
    const existingForm = document.getElementById('existing-student-form');
    
    if (registrationType === 'new') {
        newForm.style.display = 'block';
        existingForm.style.display = 'none';
        
        // Make new student fields required
        document.getElementById('name').required = true;
        document.getElementById('email').required = true;
        document.getElementById('password').required = true;
        document.getElementById('student_search').required = false;
    } else {
        newForm.style.display = 'none';
        existingForm.style.display = 'block';
        
        // Make existing student field required
        document.getElementById('name').required = false;
        document.getElementById('email').required = false;
        document.getElementById('password').required = false;
        document.getElementById('student_search').required = true;
    }
}
</script>
@endpush
