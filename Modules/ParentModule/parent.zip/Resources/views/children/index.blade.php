@extends('parentmodule::layouts.app')

@section('title', 'My Children')
@section('page-title', 'My Children')
@section('page-subtitle', 'Manage your children accounts')

@section('content')
<div class="container-fluid">
    <div class="row mb-3">
        <div class="col-md-12">
            <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                <i class="fas fa-plus mr-2"></i> Add New Child
            </a>
        </div>
    </div>
    
    <!-- Pending Requests -->
    @if($pendingRequests && $pendingRequests->count() > 0)
        <div class="card mb-4">
            <div class="card-header bg-warning text-white">
                <h5 class="mb-0"><i class="fas fa-clock mr-2"></i> Pending Requests</h5>
            </div>
            <div class="card-body">
                @foreach($pendingRequests as $request)
                    <div class="alert alert-info d-flex justify-content-between align-items-center">
                        <div>
                            <strong>{{ $request->student_name }}</strong>
                            <br>
                            <small>Request Type: {{ ucfirst(str_replace('_', ' ', $request->request_type)) }}</small>
                            <br>
                            <small>Submitted: {{ $request->created_at->diffForHumans() }}</small>
                        </div>
                        <form action="{{ route('parent.children.request.cancel', $request->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to cancel this request?')">
                                Cancel Request
                            </button>
                        </form>
                    </div>
                @endforeach
            </div>
        </div>
    @endif
    
    <!-- Children List -->
    <div class="row">
        @if($children && $children->count() > 0)
            @foreach($children as $child)
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-start mb-3">
                                <img src="{{ $child->image ? asset($child->image) : asset('public/demo/user/user.jpg') }}" 
                                     alt="{{ $child->name }}" 
                                     class="rounded-circle mr-3" 
                                     width="80" 
                                     height="80">
                                <div class="flex-grow-1">
                                    <h5 class="mb-1">{{ $child->name }}</h5>
                                    <p class="text-muted mb-1">
                                        <i class="fas fa-user-tag mr-1"></i> {{ ucfirst($child->pivot->relationship_type) }}
                                    </p>
                                    <p class="text-muted mb-1">
                                        <i class="fas fa-envelope mr-1"></i> {{ $child->email }}
                                    </p>
                                    @if($child->pivot->is_primary_parent)
                                        <span class="badge badge-primary">Primary Parent</span>
                                    @endif
                                    <span class="badge badge-{{ $child->pivot->status == 'active' ? 'success' : 'secondary' }}">
                                        {{ ucfirst($child->pivot->status) }}
                                    </span>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <div class="row text-center mb-3">
                                <div class="col-6">
                                    <h6 class="mb-0">{{ $child->enCoursesInstance->count() }}</h6>
                                    <small class="text-muted">Enrolled Courses</small>
                                </div>
                                <div class="col-6">
                                    <h6 class="mb-0">{{ $child->totalCertificate() }}</h6>
                                    <small class="text-muted">Certificates</small>
                                </div>
                            </div>
                            
                            <h6 class="mb-2">Permissions:</h6>
                            <div class="mb-3">
                                @if($child->pivot->can_make_payments)
                                    <span class="badge badge-success mr-1 mb-1"><i class="fas fa-check"></i> Make Payments</span>
                                @endif
                                @if($child->pivot->can_view_grades)
                                    <span class="badge badge-success mr-1 mb-1"><i class="fas fa-check"></i> View Grades</span>
                                @endif
                                @if($child->pivot->can_enroll_courses)
                                    <span class="badge badge-success mr-1 mb-1"><i class="fas fa-check"></i> Enroll Courses</span>
                                @endif
                            </div>
                            
                            <div class="btn-group btn-group-sm w-100" role="group">
                                <a href="{{ route('parent.children.show', $child->id) }}" class="btn btn-outline-primary">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <a href="{{ route('parent.courses.child', $child->id) }}" class="btn btn-outline-info">
                                    <i class="fas fa-book"></i> Courses
                                </a>
                                <a href="{{ route('parent.reports.child', $child->id) }}" class="btn btn-outline-success">
                                    <i class="fas fa-chart-line"></i> Reports
                                </a>
                                <a href="{{ route('parent.children.edit', $child->id) }}" class="btn btn-outline-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @else
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-child fa-4x text-muted mb-3"></i>
                        <h5>No Children Added Yet</h5>
                        <p class="text-muted">Start by adding your children to manage their education</p>
                        <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                            <i class="fas fa-plus mr-2"></i> Add Your First Child
                        </a>
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>
@endsection

