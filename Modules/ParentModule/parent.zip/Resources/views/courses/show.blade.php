@extends('parentmodule::layouts.app')

@section('title', $course->title ?? 'Course Details')
@section('page-title', $course->title ?? 'Course Details')
@section('page-subtitle', 'Course Information')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <a href="{{ route('parent.courses.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left mr-2"></i>
                Back to Courses
            </a>
        </div>
    </div>
    
    <!-- Course Header -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <img src="{{ 'https://portals.maqraatalaqsa.com/'.$course->image ?? asset('public/demo/course.jpg') }}" 
                     class="card-img-top" 
                     alt="{{ $course->title }}"
                     style="height: 300px; object-fit: cover;">
                <div class="card-body">
                    <h2 class="card-title">{{ $course->title }}</h2>
                    
                    @if(isset($instructor) && $instructor)
                    <p class="text-muted mb-3">
                        <i class="fas fa-user-tie mr-2"></i>
                        Instructor: <strong>{{ $instructor->name }}</strong>
                    </p>
                    @endif
                    
                    <div class="row mb-3">
                        <div class="col-md-3">
                            <div class="text-center p-3 bg-light rounded">
                                <i class="fas fa-clock fa-2x text-primary mb-2"></i>
                                <p class="mb-0"><strong>Duration</strong></p>
                                <p class="mb-0">{{ $course->duration ?? 'N/A' }}</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center p-3 bg-light rounded">
                                <i class="fas fa-signal fa-2x text-success mb-2"></i>
                                <p class="mb-0"><strong>Level</strong></p>
                                <p class="mb-0">{{ $course->level ?? 'All Levels' }}</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center p-3 bg-light rounded">
                                <i class="fas fa-users fa-2x text-info mb-2"></i>
                                <p class="mb-0"><strong>Students</strong></p>
                                <p class="mb-0">{{ $course->total_enrolled ?? 0 }}</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="text-center p-3 bg-light rounded">
                                <i class="fas fa-dollar-sign fa-2x text-warning mb-2"></i>
                                <p class="mb-0"><strong>Price</strong></p>
                                <p class="mb-0">
                                    @if(isset($course->price) && $course->price > 0)
                                        ${{ number_format($course->price, 2) }}
                                    @else
                                        <span class="badge badge-success">Free</span>
                                    @endif
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h5>About This Course</h5>
					<div>
					{!! $course->about ?? 'No description available.' !!}
					</div>
                    
                    
                    @if($course->outcomes)
                    <hr>
                    <h5>What You'll Learn</h5>
                    <div>{!! $course->outcomes !!}</div>
                    @endif
                    
                    @if($course->requirements)
                    <hr>
                    <h5>Requirements</h5>
                    <div>{!! $course->requirements !!}</div>
                    @endif
                    
                    @if(isset($children) && $children->count() > 0)
                    <hr>
                    <h5>Enroll a Child in This Course</h5>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle mr-2"></i>
                        Select one of your children to enroll them in this course.
                    </div>
                    <form action="{{ route('parent.courses.enroll') }}" method="POST">
                        @csrf
                        <input type="hidden" name="course_id" value="{{ $course->id }}">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="student_id">
                                        <i class="fas fa-user mr-2"></i>
                                        Select Child
                                    </label>
                                    <select name="student_id" id="student_id" class="form-control" required>
                                        <option value="">-- Select a child --</option>
                                        @foreach($children as $child)
                                            <option value="{{ $child->id }}">{{ $child->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block btn-lg">
                                    <i class="fas fa-plus-circle mr-2"></i>
                                    Enroll Child in Course
                                </button>
                            </div>
                        </div>
                    </form>
                    @else
                    <hr>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        You need to add children to your account before enrolling them in courses.
                        <a href="{{ route('parent.children.create') }}" class="btn btn-sm btn-primary ml-3">
                            <i class="fas fa-plus mr-2"></i>
                            Add Child
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
