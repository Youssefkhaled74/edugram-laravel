<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>جميع الحقوق محفوظة &copy; {{ date('Y') }} {{ config('app.name') }}</span>
        </div>
        <div class="text-center mt-2">
            <a href="#" class="small mx-2">سياسة الخصوصية</a>
            <a href="#" class="small mx-2">شروط الخدمة</a>
            <a href="#" class="small mx-2">اتصل بنا</a>
        </div>
    </div>
</footer>

