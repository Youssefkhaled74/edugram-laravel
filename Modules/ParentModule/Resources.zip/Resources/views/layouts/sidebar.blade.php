<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('parent.dashboard') }}">
        <div class="sidebar-brand-icon">
            <i class="fas fa-user-graduate"></i>
        </div>
        <div class="sidebar-brand-text mx-3">بوابة أولياء الأمور</div>
    </a>
    
    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    
    <!-- Nav Item - Dashboard -->
    <li class="nav-item {{ request()->routeIs('parent.dashboard') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.dashboard') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>الصفحة الرئيسية</span>
        </a>
    </li>
    
    <!-- Divider -->
    <hr class="sidebar-divider">
    
    <!-- Heading -->
    <div class="sidebar-heading">
        إدارة الأبناء
    </div>
    
    <!-- Nav Item - Children -->
    <li class="nav-item {{ request()->routeIs('parent.children.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.children.index') }}">
            <i class="fas fa-fw fa-users"></i>
            <span>الأبناء</span>
        </a>
    </li>
    
    <!-- Nav Item - Courses -->
    <li class="nav-item {{ request()->routeIs('parent.courses.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.courses.index') }}">
            <i class="fas fa-fw fa-book"></i>
            <span>الدورات التعليمية</span>
        </a>
    </li>
    
    <!-- Nav Item - Reports -->
    <li class="nav-item {{ request()->routeIs('parent.reports.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.reports.index') }}">
            <i class="fas fa-fw fa-chart-bar"></i>
            <span>التقارير والنتائج</span>
        </a>
    </li>
    
    <!-- Divider -->
    <hr class="sidebar-divider">
    
    <!-- Heading -->
    <div class="sidebar-heading">
        المدفوعات
    </div>
    
    <!-- Nav Item - Payments -->
    <li class="nav-item {{ request()->routeIs('parent.payments.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.payments.history') }}">
            <i class="fas fa-fw fa-credit-card"></i>
            <span>سجل المدفوعات</span>
        </a>
    </li>
    
    <!-- Divider -->
    <hr class="sidebar-divider">
    
    <!-- Nav Item - Notifications -->
    <li class="nav-item {{ request()->routeIs('parent.notifications.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.notifications.index') }}">
            <i class="fas fa-fw fa-bell"></i>
            <span>الإشعارات</span>
            @php
                $unreadCount = 0;
                if(auth()->check()) {
                    $parent = \Modules\ParentModule\Models\ParentModel::where('user_id', auth()->id())->first();
                    if($parent) {
                        $unreadCount = $parent->unreadNotifications()->count();
                    }
                }
            @endphp
            @if($unreadCount > 0)
                <span class="badge badge-danger badge-counter">{{ $unreadCount }}</span>
            @endif
        </a>
    </li>
    
    <!-- Nav Item - Profile -->
    <li class="nav-item {{ request()->routeIs('parent.profile.*') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('parent.profile') }}">
            <i class="fas fa-fw fa-user"></i>
            <span>الملف الشخصي</span>
        </a>
    </li>
    
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
    
</ul>

