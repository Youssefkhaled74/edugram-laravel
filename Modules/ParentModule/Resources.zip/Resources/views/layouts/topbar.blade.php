<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    
    <!-- Topbar Search -->
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <div class="input-group">
            <input type="text" class="form-control bg-light border-0 small" 
                   placeholder="بحث..." 
                   aria-label="بحث" 
                   aria-describedby="basic-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                    <i class="fas fa-search fa-sm"></i>
                </button>
            </div>
        </div>
    </form>
    
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        
        <!-- Nav Item - Notifications -->
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" 
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Notifications -->
                @php
                    $unreadCount = 0;
                    if(auth()->check()) {
                        $parent = \Modules\ParentModule\Models\ParentModel::where('user_id', auth()->id())->first();
                        if($parent) {
                            $unreadCount = $parent->unreadNotifications()->count();
                            $recentNotifications = $parent->notifications()->latest()->limit(5)->get();
                        }
                    }
                @endphp
                @if($unreadCount > 0)
                    <span class="badge badge-danger badge-counter">{{ $unreadCount > 9 ? '9+' : $unreadCount }}</span>
                @endif
            </a>
            <!-- Dropdown - Notifications -->
            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" 
                 aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                    الإشعارات
                </h6>
                @if(isset($recentNotifications) && $recentNotifications->count() > 0)
                    @foreach($recentNotifications as $notification)
                        <a class="dropdown-item d-flex align-items-center {{ $notification->is_read ? '' : 'bg-light' }}" 
                           href="{{ route('parent.notifications.show', $notification->id) }}">
                            <div class="mr-3">
                                <div class="icon-circle bg-primary">
                                    <i class="fas fa-bell text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">{{ $notification->created_at->diffForHumans() }}</div>
                                <span class="{{ $notification->is_read ? 'text-gray-500' : 'font-weight-bold' }}">
                                    {{ $notification->title }}
                                </span>
                            </div>
                        </a>
                    @endforeach
                    <a class="dropdown-item text-center small text-gray-500" 
                       href="{{ route('parent.notifications.index') }}">
                        عرض جميع الإشعارات
                    </a>
                @else
                    <a class="dropdown-item text-center small text-gray-500">
                        لا توجد إشعارات
                    </a>
                @endif
            </div>
        </li>
        
        <div class="topbar-divider d-none d-sm-block"></div>
        
        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    {{ auth()->user()->name }}
                </span>
                <img class="img-profile rounded-circle" 
                     src="{{ auth()->user()->avatar ?? asset('modules/parentmodule/img/default-avatar.png') }}">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" 
                 aria-labelledby="userDropdown">
                <a class="dropdown-item" href="{{ route('parent.profile') }}">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    الملف الشخصي
                </a>
                <a class="dropdown-item" href="{{ route('parent.profile.edit') }}">
                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                    الإعدادات
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    تسجيل الخروج
                </a>
            </div>
        </li>
        
    </ul>
    
</nav>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutModalLabel">تسجيل الخروج</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="إغلاق">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                هل أنت متأكد من تسجيل الخروج؟
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    إلغاء
                </button>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="btn btn-primary">
                        تسجيل الخروج
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

