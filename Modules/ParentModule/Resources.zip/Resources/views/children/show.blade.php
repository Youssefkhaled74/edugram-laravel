@extends('parentmodule::layouts.master')

@section('title', 'تفاصيل الطالب')

@section('content')
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">{{ $child->name }}</h1>
    <div>
        <a href="{{ route('parent.children.edit', $child->id) }}" class="btn btn-primary">
            <i class="fas fa-edit"></i> تعديل الصلاحيات
        </a>
        <a href="{{ route('parent.children.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-right"></i> رجوع
        </a>
    </div>
</div>

<!-- Student Info Row -->
<div class="row">
    
    <!-- Student Information Card -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow h-100">
            <div class="card-header bg-primary text-white">
                <h6 class="m-0 font-weight-bold">
                    <i class="fas fa-user"></i> معلومات الطالب
                </h6>
            </div>
            <div class="card-body text-center">
                <img class="img-profile rounded-circle mb-3" 
                     src="{{ $child->avatar ?? asset('modules/parentmodule/img/default-avatar.png') }}" 
                     style="width: 120px; height: 120px;">
                <h4 class="mb-1">{{ $child->name }}</h4>
                <p class="text-muted mb-3">{{ $child->email }}</p>
                
                <hr>
                
                <div class="text-right">
                    <p class="mb-2">
                        <i class="fas fa-phone text-primary"></i> 
                        <strong>الهاتف:</strong> {{ $child->phone ?? 'غير محدد' }}
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-birthday-cake text-primary"></i> 
                        <strong>تاريخ الميلاد:</strong> {{ $child->date_of_birth ?? 'غير محدد' }}
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-venus-mars text-primary"></i> 
                        <strong>الجنس:</strong> 
                        @if($child->gender == 'male') ذكر
                        @elseif($child->gender == 'female') أنثى
                        @else غير محدد
                        @endif
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-heart text-primary"></i> 
                        <strong>صلة القرابة:</strong> 
                        @switch($relationship->relationship_type)
                            @case('father') الأب @break
                            @case('mother') الأم @break
                            @case('guardian') الوصي @break
                            @default أخرى
                        @endswitch
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="col-lg-8 mb-4">
        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            إجمالي الدورات
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['total_courses'] }}</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            قيد التقدم
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['in_progress_courses'] }}</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            الاختبارات
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['total_quizzes'] }}</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            المعدل
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['average_score'] }}%</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Permissions Card -->
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-key"></i> الصلاحيات
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-2x {{ $relationship->can_view_grades ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' }} ml-2"></i>
                            <div>
                                <strong>عرض الدرجات</strong>
                                <br>
                                <small class="text-muted">السماح بعرض درجات الاختبارات</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-2x {{ $relationship->can_make_payments ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' }} ml-2"></i>
                            <div>
                                <strong>إجراء المدفوعات</strong>
                                <br>
                                <small class="text-muted">السماح بدفع رسوم الدورات</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-2x {{ $relationship->can_view_attendance ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' }} ml-2"></i>
                            <div>
                                <strong>عرض الحضور</strong>
                                <br>
                                <small class="text-muted">السماح بعرض سجل الحضور</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-2x {{ $relationship->can_enroll_courses ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' }} ml-2"></i>
                            <div>
                                <strong>تسجيل الدورات</strong>
                                <br>
                                <small class="text-muted">السماح بتسجيل الطالب في دورات جديدة</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Enrolled Courses -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-book"></i> الدورات المسجلة
        </h6>
        @if($relationship->can_enroll_courses)
            <a href="{{ route('parent.courses.child', $child->id) }}" class="btn btn-sm btn-primary">
                <i class="fas fa-plus"></i> تسجيل في دورة جديدة
            </a>
        @endif
    </div>
    <div class="card-body">
        @if(count($enrolledCourses) > 0)
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>اسم الدورة</th>
                            <th>تاريخ التسجيل</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($enrolledCourses as $enrollment)
                            @if($enrollment->course)
                            <tr>
                                <td>{{ $enrollment->course->title }}</td>
                                <td>{{ $enrollment->created_at->format('Y-m-d') }}</td>
                                <td>
                                    <span class="badge badge-success">نشط</span>
                                </td>
                                <td>
                                    <a href="{{ route('parent.courses.show', $enrollment->course->id) }}" 
                                       class="btn btn-sm btn-outline-primary">
                                        عرض
                                    </a>
                                </td>
                            </tr>
                            @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-center py-4">
                <i class="fas fa-book fa-3x text-gray-300 mb-3"></i>
                <p class="text-gray-500">لم يتم التسجيل في أي دورات بعد</p>
            </div>
        @endif
    </div>
</div>

<!-- Quiz Results -->
@if($relationship->can_view_grades && count($quizResults) > 0)
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-clipboard-list"></i> نتائج الاختبارات الأخيرة
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>اسم الاختبار</th>
                        <th>الدرجة</th>
                        <th>النسبة المئوية</th>
                        <th>التاريخ</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($quizResults as $result)
                        @if($result->quiz)
                        <tr>
                            <td>{{ $result->quiz->title }}</td>
                            <td>{{ $result->score }} / {{ $result->total_score }}</td>
                            <td>{{ round(($result->score / $result->total_score) * 100, 2) }}%</td>
                            <td>{{ $result->created_at->format('Y-m-d') }}</td>
                            <td>
                                @if(($result->score / $result->total_score) * 100 >= 50)
                                    <span class="badge badge-success">نجح</span>
                                @else
                                    <span class="badge badge-danger">رسب</span>
                                @endif
                            </td>
                        </tr>
                        @endif
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endif

@endsection

