@extends('parentmodule::layouts.master')

@section('title', 'إضافة ابن')

@section('content')
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">إضافة ابن</h1>
    <a href="{{ route('parent.children.index') }}" class="btn btn-secondary">
        <i class="fas fa-arrow-right"></i> رجوع
    </a>
</div>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">معلومات الابن</h6>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('parent.children.store') }}">
                    @csrf
                    
                    <!-- Registration Type -->
                    <div class="form-group">
                        <label class="font-weight-bold">نوع التسجيل <span class="text-danger">*</span></label>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="typeNew" name="registration_type" value="new" 
                                   class="custom-control-input" checked>
                            <label class="custom-control-label" for="typeNew">
                                إنشاء حساب طالب جديد
                            </label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="typeExisting" name="registration_type" value="existing" 
                                   class="custom-control-input">
                            <label class="custom-control-label" for="typeExisting">
                                ربط بحساب طالب موجود
                            </label>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- New Student Fields -->
                    <div id="newStudentFields">
                        <h6 class="font-weight-bold mb-3">معلومات الطالب الجديد</h6>
                        
                        <div class="form-group">
                            <label for="name">الاسم الكامل <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" value="{{ old('name') }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">البريد الإلكتروني <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                           id="email" name="email" value="{{ old('email') }}" required>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password">كلمة المرور <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                           id="password" name="password" required>
                                    @error('password')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">رقم الهاتف</label>
                                    <input type="tel" class="form-control @error('phone') is-invalid @enderror" 
                                           id="phone" name="phone" value="{{ old('phone') }}">
                                    @error('phone')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="date_of_birth">تاريخ الميلاد</label>
                                    <input type="date" class="form-control @error('date_of_birth') is-invalid @enderror" 
                                           id="date_of_birth" name="date_of_birth" value="{{ old('date_of_birth') }}">
                                    @error('date_of_birth')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="gender">الجنس</label>
                            <select class="form-control @error('gender') is-invalid @enderror" id="gender" name="gender">
                                <option value="">اختر الجنس</option>
                                <option value="male" {{ old('gender') == 'male' ? 'selected' : '' }}>ذكر</option>
                                <option value="female" {{ old('gender') == 'female' ? 'selected' : '' }}>أنثى</option>
                            </select>
                            @error('gender')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <!-- Existing Student Fields -->
                    <div id="existingStudentFields" style="display: none;">
                        <h6 class="font-weight-bold mb-3">اختر الطالب</h6>
                        
                        <div class="form-group">
                            <label for="student_id">الطالب <span class="text-danger">*</span></label>
                            <select class="form-control @error('student_id') is-invalid @enderror" 
                                    id="student_id" name="student_id">
                                <option value="">اختر الطالب</option>
                                <!-- This should be populated dynamically from your database -->
                            </select>
                            @error('student_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="form-text text-muted">
                                اختر الطالب من القائمة للربط بحسابك
                            </small>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- Relationship Information -->
                    <h6 class="font-weight-bold mb-3">معلومات صلة القرابة</h6>
                    
                    <div class="form-group">
                        <label for="relationship_type">صلة القرابة <span class="text-danger">*</span></label>
                        <select class="form-control @error('relationship_type') is-invalid @enderror" 
                                id="relationship_type" name="relationship_type" required>
                            <option value="">اختر صلة القرابة</option>
                            <option value="father" {{ old('relationship_type') == 'father' ? 'selected' : '' }}>الأب</option>
                            <option value="mother" {{ old('relationship_type') == 'mother' ? 'selected' : '' }}>الأم</option>
                            <option value="guardian" {{ old('relationship_type') == 'guardian' ? 'selected' : '' }}>الوصي</option>
                            <option value="other" {{ old('relationship_type') == 'other' ? 'selected' : '' }}>أخرى</option>
                        </select>
                        @error('relationship_type')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="is_primary_parent" 
                                   name="is_primary_parent" value="1" {{ old('is_primary_parent') ? 'checked' : '' }}>
                            <label class="custom-control-label" for="is_primary_parent">
                                أنا ولي الأمر الرئيسي
                            </label>
                        </div>
                        <small class="form-text text-muted">
                            ولي الأمر الرئيسي له صلاحيات كاملة على حساب الطالب
                        </small>
                    </div>
                    
                    <hr>
                    
                    <!-- Submit Buttons -->
                    <div class="form-group mb-0">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ
                        </button>
                        <a href="{{ route('parent.children.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> إلغاء
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Toggle between new and existing student fields
    $('input[name="registration_type"]').change(function() {
        if ($(this).val() === 'new') {
            $('#newStudentFields').show();
            $('#existingStudentFields').hide();
            $('#newStudentFields input[required]').prop('disabled', false);
            $('#existingStudentFields select[required]').prop('disabled', true);
        } else {
            $('#newStudentFields').hide();
            $('#existingStudentFields').show();
            $('#newStudentFields input[required]').prop('disabled', true);
            $('#existingStudentFields select[required]').prop('disabled', false);
        }
    });
});
</script>
@endpush

