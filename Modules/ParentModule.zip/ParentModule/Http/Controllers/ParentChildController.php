<?php

namespace Modules\ParentModule\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Modules\ParentModule\Models\ParentModel;
use Modules\ParentModule\Models\ParentChild;
use Modules\ParentModule\Models\ParentStudentRequest;
use Modules\RolePermission\Entities\Role;

class ParentChildController extends Controller
{
    /**
     * Display all children.
     */
    public function index()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $children = $parent->children()
            ->withPivot([
                'relationship_type',
                'is_primary_parent',
                'can_make_payments',
                'can_view_grades',
                'can_view_attendance',
                'can_communicate_teachers',
                'can_enroll_courses',
                'status'
            ])
            ->get();

        $pendingRequests = $parent->pendingRequests()->get();

        return view('parentmodule::children.index', compact('children', 'pendingRequests', 'parent'));
    }

    /**
     * Show form to add a child.
     */
    public function create()
    {
        return view('parentmodule::children.create');
    }

    /**
     * Store a new child request.
     */
    public function store(Request $request)
    {
        $request->validate([
            'request_type' => 'required|in:link_existing,create_new',
            'student_name' => 'required|string|max:191',
            'student_email' => 'required_if:request_type,link_existing|email|nullable',
            'student_dob' => 'nullable|date',
            'student_national_id' => 'nullable|string|max:191',
            'relationship_type' => 'required|in:father,mother,guardian,grandfather,grandmother,uncle,aunt,sibling,other',
            'supporting_documents.*' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Handle file uploads
        $documents = [];
        if ($request->hasFile('supporting_documents')) {
            foreach ($request->file('supporting_documents') as $file) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('parent_documents', $filename, 'public');
                $documents[] = 'storage/' . $path;
            }
        }

        // Check if linking existing student
        $studentId = null;
        if ($request->request_type === 'link_existing' && $request->student_email) {
            $student = User::where('email', $request->student_email)->first();
            
            if ($student) {
                $studentRole = Role::where('name', 'Student')->first();
                
                if ($student->role_id != $studentRole->id) {
                    return redirect()->back()
                        ->with('error', 'The email provided does not belong to a student account.')
                        ->withInput();
                }
                
                // Check if relationship already exists
                $existingRelation = ParentChild::where('parent_id', $parent->id)
                    ->where('student_id', $student->id)
                    ->first();
                
                if ($existingRelation) {
                    return redirect()->back()
                        ->with('error', 'This student is already linked to your account.')
                        ->withInput();
                }
                
                $studentId = $student->id;
            } else {
                return redirect()->back()
                    ->with('error', 'No student found with this email address.')
                    ->withInput();
            }
        }

        // Create request
        ParentStudentRequest::create([
            'parent_id' => $parent->id,
            'student_email' => $request->student_email,
            'student_id' => $studentId,
            'student_name' => $request->student_name,
            'student_dob' => $request->student_dob,
            'student_national_id' => $request->student_national_id,
            'relationship_type' => $request->relationship_type,
            'request_type' => $request->request_type,
            'status' => 'pending',
            'supporting_documents' => $documents,
            'lms_id' => 1
        ]);

        return redirect()->route('parent.children.index')
            ->with('success', 'Your request has been submitted and is pending admin approval.');
    }

    /**
     * Display child details.
     */
    public function show($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $child = $parent->children()->where('users.id', $id)->first();

        if (!$child) {
            return redirect()->route('parent.children.index')
                ->with('error', 'Child not found.');
        }

        // Get child's enrollments
        $enrollments = $child->enCoursesInstance()
            ->with('course')
            ->orderBy('created_at', 'desc')
            ->get();

        // Get child's quiz results
        $quizResults = StudentTakeOnlineQuiz::where('student_id', $child->id)
            ->with('quiz')
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        // Get relationship details
        $relationship = ParentChild::where('parent_id', $parent->id)
            ->where('student_id', $child->id)
            ->first();

        return view('parentmodule::children.show', compact(
            'child',
            'parent',
            'enrollments',
            'quizResults',
            'relationship'
        ));
    }

    /**
     * Show form to edit child permissions.
     */
    public function edit($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $relationship = ParentChild::where('parent_id', $parent->id)
            ->where('student_id', $id)
            ->first();

        if (!$relationship) {
            return redirect()->route('parent.children.index')
                ->with('error', 'Child not found.');
        }

        $child = $relationship->student;

        return view('parentmodule::children.edit', compact('child', 'relationship', 'parent'));
    }

    /**
     * Update child permissions.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'can_make_payments' => 'nullable|boolean',
            'can_view_grades' => 'nullable|boolean',
            'can_view_attendance' => 'nullable|boolean',
            'can_communicate_teachers' => 'nullable|boolean',
            'can_enroll_courses' => 'nullable|boolean',
            'notes' => 'nullable|string',
        ]);

        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $relationship = ParentChild::where('parent_id', $parent->id)
            ->where('student_id', $id)
            ->first();

        if (!$relationship) {
            return redirect()->route('parent.children.index')
                ->with('error', 'Child not found.');
        }

        $relationship->update([
            'can_make_payments' => $request->has('can_make_payments'),
            'can_view_grades' => $request->has('can_view_grades'),
            'can_view_attendance' => $request->has('can_view_attendance'),
            'can_communicate_teachers' => $request->has('can_communicate_teachers'),
            'can_enroll_courses' => $request->has('can_enroll_courses'),
            'notes' => $request->notes,
        ]);

        return redirect()->route('parent.children.show', $id)
            ->with('success', 'Child permissions updated successfully.');
    }

    /**
     * Remove child from parent account.
     */
    public function destroy($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $relationship = ParentChild::where('parent_id', $parent->id)
            ->where('student_id', $id)
            ->first();

        if (!$relationship) {
            return redirect()->route('parent.children.index')
                ->with('error', 'Child not found.');
        }

        $relationship->delete();

        return redirect()->route('parent.children.index')
            ->with('success', 'Child removed from your account successfully.');
    }

    /**
     * Cancel a pending request.
     */
    public function cancelRequest($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $request = ParentStudentRequest::where('id', $id)
            ->where('parent_id', $parent->id)
            ->first();

        if (!$request) {
            return redirect()->route('parent.children.index')
                ->with('error', 'Request not found.');
        }

        if ($request->status !== 'pending') {
            return redirect()->route('parent.children.index')
                ->with('error', 'Only pending requests can be cancelled.');
        }

        $request->cancel();

        return redirect()->route('parent.children.index')
            ->with('success', 'Request cancelled successfully.');
    }
}

