<?php

namespace Modules\ParentModule\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Modules\ParentModule\Models\ParentModel;
use Modules\CourseSetting\Entities\CourseEnrolled;
use Modules\Quiz\Entities\StudentTakeOnlineQuiz;
use Modules\Quiz\Entities\OnlineQuiz;
use Modules\Certificate\Entities\CertificateRecord;
use Carbon\Carbon;

class ParentReportController extends Controller
{
    /**
     * Display overall progress report for all children.
     */
    public function index()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $children = $parent->activeChildren()->get();

        $childrenReports = [];

        foreach ($children as $child) {
            // Get course statistics
            $enrollments = CourseEnrolled::where('user_id', $child->id)->with('course')->get();
            $totalCourses = $enrollments->count();
            $completedCourses = 0;
            $inProgressCourses = 0;

            foreach ($enrollments as $enrollment) {
                if ($enrollment->course) {
                    $progress = $enrollment->course->loginUserTotalPercentage ?? 0;
                    if ($progress >= 100) {
                        $completedCourses++;
                    } else {
                        $inProgressCourses++;
                    }
                }
            }

            // Get quiz statistics
            $quizResults = StudentTakeOnlineQuiz::where('student_id', $child->id)->get();
            $totalQuizzes = $quizResults->count();
            $averageScore = $quizResults->avg('score') ?? 0;

            // Get certificates
            $certificates = CertificateRecord::where('student_id', $child->id)->count();

            // Get recent activity
            $recentActivity = $child->last_activity_at;

            $childrenReports[] = [
                'student' => $child,
                'relationship' => $child->pivot->relationship_type,
                'total_courses' => $totalCourses,
                'completed_courses' => $completedCourses,
                'in_progress_courses' => $inProgressCourses,
                'total_quizzes' => $totalQuizzes,
                'average_score' => round($averageScore, 2),
                'certificates' => $certificates,
                'recent_activity' => $recentActivity,
            ];
        }

        return view('parentmodule::reports.index', compact('childrenReports', 'parent'));
    }

    /**
     * Display detailed report for a specific child.
     */
    public function childReport($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // Check if parent can view grades
        if (!$parent->canPerformAction($childId, 'view_grades')) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'You do not have permission to view this child\'s reports.');
        }

        // Get course progress
        $enrollments = CourseEnrolled::where('user_id', $childId)
            ->with('course.category')
            ->get();

        $courseStats = [
            'total' => $enrollments->count(),
            'completed' => 0,
            'in_progress' => 0,
            'not_started' => 0,
        ];

        $courseProgress = [];
        foreach ($enrollments as $enrollment) {
            if ($enrollment->course) {
                $progress = $enrollment->course->loginUserTotalPercentage ?? 0;
                
                if ($progress >= 100) {
                    $courseStats['completed']++;
                } elseif ($progress > 0) {
                    $courseStats['in_progress']++;
                } else {
                    $courseStats['not_started']++;
                }

                $courseProgress[] = [
                    'course' => $enrollment->course,
                    'progress' => $progress,
                    'enrolled_at' => $enrollment->created_at,
                ];
            }
        }

        // Get quiz results
        $quizResults = StudentTakeOnlineQuiz::where('student_id', $childId)
            ->with('quiz')
            ->orderBy('created_at', 'desc')
            ->get();

        $quizStats = [
            'total_attempted' => $quizResults->count(),
            'average_score' => round($quizResults->avg('score') ?? 0, 2),
            'highest_score' => $quizResults->max('score') ?? 0,
            'lowest_score' => $quizResults->min('score') ?? 0,
        ];

        // Get certificates
        $certificates = CertificateRecord::where('student_id', $childId)
            ->orderBy('created_at', 'desc')
            ->get();

        // Get activity timeline (last 30 days)
        $activityData = $this->getActivityTimeline($childId, 30);

        return view('parentmodule::reports.child-report', compact(
            'child',
            'parent',
            'courseStats',
            'courseProgress',
            'quizResults',
            'quizStats',
            'certificates',
            'activityData'
        ));
    }

    /**
     * Display quiz results for a child.
     */
    public function quizResults($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // Check if parent can view grades
        if (!$parent->canPerformAction($childId, 'view_grades')) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'You do not have permission to view this child\'s quiz results.');
        }

        $quizResults = StudentTakeOnlineQuiz::where('student_id', $childId)
            ->with(['quiz', 'course'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        $stats = [
            'total_attempted' => StudentTakeOnlineQuiz::where('student_id', $childId)->count(),
            'average_score' => round(StudentTakeOnlineQuiz::where('student_id', $childId)->avg('score') ?? 0, 2),
            'passed' => StudentTakeOnlineQuiz::where('student_id', $childId)->where('status', 'pass')->count(),
            'failed' => StudentTakeOnlineQuiz::where('student_id', $childId)->where('status', 'fail')->count(),
        ];

        return view('parentmodule::reports.quiz-results', compact(
            'child',
            'parent',
            'quizResults',
            'stats'
        ));
    }

    /**
     * Display quiz result details.
     */
    public function quizResultDetail($childId, $resultId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // Check if parent can view grades
        if (!$parent->canPerformAction($childId, 'view_grades')) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'You do not have permission to view this child\'s quiz results.');
        }

        $quizResult = StudentTakeOnlineQuiz::where('id', $resultId)
            ->where('student_id', $childId)
            ->with(['quiz', 'course'])
            ->first();

        if (!$quizResult) {
            return redirect()->route('parent.reports.quiz-results', $childId)
                ->with('error', 'Quiz result not found.');
        }

        return view('parentmodule::reports.quiz-result-detail', compact(
            'child',
            'parent',
            'quizResult'
        ));
    }

    /**
     * Display certificates for a child.
     */
    public function certificates($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        $certificates = CertificateRecord::where('student_id', $childId)
            ->with('course')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('parentmodule::reports.certificates', compact(
            'child',
            'parent',
            'certificates'
        ));
    }

    /**
     * Download certificate.
     */
    public function downloadCertificate($childId, $certificateId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        $certificate = CertificateRecord::where('id', $certificateId)
            ->where('student_id', $childId)
            ->first();

        if (!$certificate) {
            return redirect()->route('parent.reports.certificates', $childId)
                ->with('error', 'Certificate not found.');
        }

        // Redirect to certificate download or view page
        return redirect()->route('certificateDownload', $certificate->certificate_number);
    }

    /**
     * Get activity timeline for a child.
     */
    private function getActivityTimeline($childId, $days = 30)
    {
        $startDate = Carbon::now()->subDays($days);

        // Get course enrollments
        $enrollments = CourseEnrolled::where('user_id', $childId)
            ->where('created_at', '>=', $startDate)
            ->get();

        // Get quiz attempts
        $quizAttempts = StudentTakeOnlineQuiz::where('student_id', $childId)
            ->where('created_at', '>=', $startDate)
            ->get();

        // Get certificates
        $certificates = CertificateRecord::where('student_id', $childId)
            ->where('created_at', '>=', $startDate)
            ->get();

        $activities = [];

        foreach ($enrollments as $enrollment) {
            $activities[] = [
                'type' => 'enrollment',
                'date' => $enrollment->created_at,
                'description' => 'Enrolled in ' . ($enrollment->course->title ?? 'Unknown Course'),
            ];
        }

        foreach ($quizAttempts as $attempt) {
            $activities[] = [
                'type' => 'quiz',
                'date' => $attempt->created_at,
                'description' => 'Completed quiz: ' . ($attempt->quiz->title ?? 'Unknown Quiz') . ' (Score: ' . $attempt->score . ')',
            ];
        }

        foreach ($certificates as $certificate) {
            $activities[] = [
                'type' => 'certificate',
                'date' => $certificate->created_at,
                'description' => 'Earned certificate for ' . ($certificate->course->title ?? 'Unknown Course'),
            ];
        }

        // Sort by date descending
        usort($activities, function($a, $b) {
            return $b['date'] <=> $a['date'];
        });

        return $activities;
    }

    /**
     * Export child report as PDF.
     */
    public function exportReport($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.reports.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // TODO: Implement PDF export functionality
        // This would generate a comprehensive PDF report of the child's progress

        return redirect()->back()
            ->with('info', 'PDF export feature coming soon.');
    }
}

