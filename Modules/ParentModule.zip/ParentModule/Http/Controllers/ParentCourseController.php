<?php

namespace Modules\ParentModule\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Modules\ParentModule\Models\ParentModel;
use Modules\ParentModule\Models\ParentChild;
use Modules\CourseSetting\Entities\Course;
use Modules\CourseSetting\Entities\CourseEnrolled;
use Modules\CourseSetting\Entities\Category;

class ParentCourseController extends Controller
{
    /**
     * Display all courses for all children.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $children = $parent->activeChildren()->get();
        
        // Filter by child if specified
        $selectedChildId = $request->get('child_id');
        
        if ($selectedChildId) {
            $enrollments = CourseEnrolled::where('user_id', $selectedChildId)
                ->with(['course.category', 'course.user'])
                ->orderBy('created_at', 'desc')
                ->paginate(12);
        } else {
            // Get enrollments for all children
            $childIds = $children->pluck('id')->toArray();
            $enrollments = CourseEnrolled::whereIn('user_id', $childIds)
                ->with(['course.category', 'course.user', 'user'])
                ->orderBy('created_at', 'desc')
                ->paginate(12);
        }

        return view('parentmodule::courses.index', compact(
            'enrollments',
            'children',
            'selectedChildId',
            'parent'
        ));
    }

    /**
     * Display courses for a specific child.
     */
    public function childCourses($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'Child not found or you do not have permission to view their courses.');
        }

        // Check if parent can view grades
        if (!$parent->canPerformAction($childId, 'view_grades')) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'You do not have permission to view this child\'s courses.');
        }

        $enrollments = CourseEnrolled::where('user_id', $childId)
            ->with(['course.category', 'course.user'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        $stats = [
            'total_courses' => $enrollments->total(),
            'completed' => 0,
            'in_progress' => 0,
            'not_started' => 0,
        ];

        foreach ($enrollments as $enrollment) {
            if ($enrollment->course) {
                $progress = $enrollment->course->loginUserTotalPercentage ?? 0;
                if ($progress >= 100) {
                    $stats['completed']++;
                } elseif ($progress > 0) {
                    $stats['in_progress']++;
                } else {
                    $stats['not_started']++;
                }
            }
        }

        return view('parentmodule::courses.child-courses', compact(
            'child',
            'enrollments',
            'stats',
            'parent'
        ));
    }

    /**
     * Display course details.
     */
    public function show($childId, $courseId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // Check if parent can view grades
        if (!$parent->canPerformAction($childId, 'view_grades')) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'You do not have permission to view this child\'s course details.');
        }

        // Get enrollment
        $enrollment = CourseEnrolled::where('user_id', $childId)
            ->where('course_id', $courseId)
            ->with(['course.category', 'course.user', 'course.chapters.lessons'])
            ->first();

        if (!$enrollment) {
            return redirect()->route('parent.courses.child', $childId)
                ->with('error', 'Course enrollment not found.');
        }

        $course = $enrollment->course;

        // Get course progress
        $totalLessons = 0;
        $completedLessons = 0;
        
        if ($course && $course->chapters) {
            foreach ($course->chapters as $chapter) {
                $totalLessons += $chapter->lessons->count();
                // Get completed lessons for this child
                $completedLessons += $chapter->lessons->filter(function($lesson) use ($childId) {
                    return $lesson->isCompleted($childId);
                })->count();
            }
        }

        $progress = $totalLessons > 0 ? round(($completedLessons / $totalLessons) * 100, 2) : 0;

        return view('parentmodule::courses.show', compact(
            'child',
            'course',
            'enrollment',
            'progress',
            'totalLessons',
            'completedLessons',
            'parent'
        ));
    }

    /**
     * Display available courses for enrollment.
     */
    public function availableCourses($childId)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Verify parent has access to this child
        $child = $parent->activeChildren()->where('users.id', $childId)->first();

        if (!$child) {
            return redirect()->route('parent.courses.index')
                ->with('error', 'Child not found or you do not have permission.');
        }

        // Check if parent can enroll courses
        if (!$parent->canPerformAction($childId, 'enroll_courses')) {
            return redirect()->route('parent.courses.child', $childId)
                ->with('error', 'You do not have permission to enroll courses for this child.');
        }

        // Get enrolled course IDs
        $enrolledCourseIds = CourseEnrolled::where('user_id', $childId)
            ->pluck('course_id')
            ->toArray();

        // Get available courses (not enrolled)
        $courses = Course::where('status', 1)
            ->whereNotIn('id', $enrolledCourseIds)
            ->with(['category', 'user'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        $categories = Category::where('status', 1)->get();

        return view('parentmodule::courses.available', compact(
            'child',
            'courses',
            'categories',
            'parent'
        ));
    }

    /**
     * Search and filter courses.
     */
    public function search(Request $request)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $query = Course::where('status', 1);

        // Search by keyword
        if ($request->has('keyword') && $request->keyword) {
            $keyword = $request->keyword;
            $query->where(function($q) use ($keyword) {
                $q->where('title', 'like', "%{$keyword}%")
                  ->orWhere('about', 'like', "%{$keyword}%");
            });
        }

        // Filter by category
        if ($request->has('category_id') && $request->category_id) {
            $query->where('category_id', $request->category_id);
        }

        // Filter by price
        if ($request->has('price_type')) {
            if ($request->price_type === 'free') {
                $query->where('price', 0);
            } elseif ($request->price_type === 'paid') {
                $query->where('price', '>', 0);
            }
        }

        $courses = $query->with(['category', 'user'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        $categories = Category::where('status', 1)->get();
        $children = $parent->activeChildren()->get();

        return view('parentmodule::courses.search', compact(
            'courses',
            'categories',
            'children',
            'parent'
        ));
    }
}

