<?php

namespace Modules\ParentModule\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Modules\ParentModule\Models\ParentModel;
use Modules\ParentModule\Models\ParentChild;
use Modules\ParentModule\Models\ParentPayment;
use Modules\ParentModule\Models\ParentNotification;
use Modules\CourseSetting\Entities\CourseEnrolled;
use Modules\Quiz\Entities\StudentTakeOnlineQuiz;

class ParentDashboardController extends Controller
{
    /**
     * Display parent dashboard.
     */
    public function index()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        if (!$parent) {
            return redirect()->route('parent.profile.create')
                ->with('error', 'Please complete your parent profile first.');
        }

        // Get all children
        $children = $parent->activeChildren()->get();
        
        // Get statistics
        $stats = [
            'total_children' => $children->count(),
            'total_payments' => $parent->payments()->completed()->sum('amount'),
            'pending_payments' => $parent->payments()->pending()->sum('amount'),
            'unread_notifications' => $parent->unreadNotifications()->count(),
        ];

        // Get recent notifications
        $recentNotifications = $parent->notifications()
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // Get recent payments
        $recentPayments = $parent->payments()
            ->with(['student', 'course'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // Get children with their course progress
        $childrenData = [];
        foreach ($children as $child) {
            $enrollments = CourseEnrolled::where('user_id', $child->id)
                ->with('course')
                ->get();
            
            $totalCourses = $enrollments->count();
            $completedCourses = 0;
            $inProgressCourses = 0;

            foreach ($enrollments as $enrollment) {
                if ($enrollment->course && $enrollment->course->loginUserTotalPercentage >= 100) {
                    $completedCourses++;
                } else {
                    $inProgressCourses++;
                }
            }

            $childrenData[] = [
                'student' => $child,
                'relationship' => $child->pivot->relationship_type,
                'total_courses' => $totalCourses,
                'completed_courses' => $completedCourses,
                'in_progress_courses' => $inProgressCourses,
                'recent_activity' => $child->last_activity_at,
            ];
        }

        return view('parentmodule::dashboard.index', compact(
            'parent',
            'children',
            'stats',
            'recentNotifications',
            'recentPayments',
            'childrenData'
        ));
    }

    /**
     * Display parent profile.
     */
    public function profile()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        return view('parentmodule::dashboard.profile', compact('user', 'parent'));
    }

    /**
     * Update parent profile.
     */
    public function updateProfile(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:191',
            'phone' => 'nullable|string|max:100',
            'address' => 'nullable|string',
            'city' => 'nullable|string',
            'country' => 'nullable|string',
            'national_id' => 'nullable|string|max:191',
            'occupation' => 'nullable|string|max:191',
            'workplace' => 'nullable|string|max:191',
            'emergency_contact' => 'nullable|string|max:191',
            'emergency_contact_name' => 'nullable|string|max:191',
            'emergency_contact_relation' => 'nullable|string|max:191',
            'preferred_contact_method' => 'nullable|in:email,phone,sms,whatsapp',
        ]);

        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        // Update user information
        $user->update([
            'name' => $request->name,
            'phone' => $request->phone,
            'address' => $request->address,
            'city' => $request->city,
            'country' => $request->country,
        ]);

        // Update parent information
        if ($parent) {
            $parent->update([
                'national_id' => $request->national_id,
                'occupation' => $request->occupation,
                'workplace' => $request->workplace,
                'emergency_contact' => $request->emergency_contact,
                'emergency_contact_name' => $request->emergency_contact_name,
                'emergency_contact_relation' => $request->emergency_contact_relation,
                'preferred_contact_method' => $request->preferred_contact_method ?? 'email',
            ]);
        }

        return redirect()->back()
            ->with('success', 'Profile updated successfully.');
    }

    /**
     * Display all notifications.
     */
    public function notifications()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $notifications = $parent->notifications()
            ->with('student')
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('parentmodule::dashboard.notifications', compact('notifications', 'parent'));
    }

    /**
     * Mark notification as read.
     */
    public function markNotificationRead($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $notification = ParentNotification::where('id', $id)
            ->where('parent_id', $parent->id)
            ->first();

        if ($notification) {
            $notification->markAsRead();
            return response()->json(['success' => true]);
        }

        return response()->json(['success' => false], 404);
    }

    /**
     * Mark all notifications as read.
     */
    public function markAllNotificationsRead()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $parent->unreadNotifications()->update([
            'is_read' => true,
            'read_at' => now()
        ]);

        return redirect()->back()
            ->with('success', 'All notifications marked as read.');
    }

    /**
     * Display payment history.
     */
    public function paymentHistory()
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $payments = $parent->payments()
            ->with(['student', 'course'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        $stats = [
            'total_paid' => $parent->payments()->completed()->sum('amount'),
            'total_pending' => $parent->payments()->pending()->sum('amount'),
            'total_refunded' => $parent->payments()->where('payment_status', 'refunded')->sum('refund_amount'),
        ];

        return view('parentmodule::dashboard.payment-history', compact('payments', 'stats', 'parent'));
    }

    /**
     * Download payment invoice.
     */
    public function downloadInvoice($id)
    {
        $user = Auth::user();
        $parent = ParentModel::where('user_id', $user->id)->first();

        $payment = ParentPayment::where('id', $id)
            ->where('parent_id', $parent->id)
            ->first();

        if (!$payment) {
            return redirect()->back()
                ->with('error', 'Payment not found.');
        }

        if (!$payment->invoice_path || !file_exists(public_path($payment->invoice_path))) {
            return redirect()->back()
                ->with('error', 'Invoice not available.');
        }

        return response()->download(public_path($payment->invoice_path));
    }
}

