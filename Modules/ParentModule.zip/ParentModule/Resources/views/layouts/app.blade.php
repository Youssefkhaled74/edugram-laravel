<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Parent Portal') - {{ config('app.name', 'LMS') }}</title>
    
    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('public/css/app.css') }}">
    <link rel="stylesheet" href="{{ asset('public/backend/css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    @stack('styles')
    
    <style>
        .parent-sidebar {
            min-height: 100vh;
            background: #2c3e50;
            color: white;
        }
        .parent-sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-radius: 5px;
            margin: 5px 10px;
        }
        .parent-sidebar .nav-link:hover,
        .parent-sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .parent-header {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 15px 30px;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .child-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        .child-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        @include('parentmodule::partials.sidebar')
        
        <!-- Main Content -->
        <div class="flex-grow-1">
            <!-- Header -->
            @include('parentmodule::partials.header')
            
            <!-- Page Content -->
            <main class="p-4">
                @include('parentmodule::partials.alerts')
                
                @yield('content')
            </main>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    
    @stack('scripts')
    
    <script>
        // Mark notification as read
        function markNotificationRead(id) {
            $.post("{{ route('parent.notifications.read', '') }}/" + id, {
                _token: "{{ csrf_token() }}"
            }).done(function() {
                $('#notification-' + id).fadeOut();
            });
        }
    </script>
</body>
</html>

