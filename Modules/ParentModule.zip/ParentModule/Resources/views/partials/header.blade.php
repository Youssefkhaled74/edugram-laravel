<div class="parent-header d-flex justify-content-between align-items-center">
    <div>
        <h5 class="mb-0">@yield('page-title', 'Dashboard')</h5>
        <small class="text-muted">@yield('page-subtitle', 'Welcome to Parent Portal')</small>
    </div>
    
    <div class="d-flex align-items-center">
        <!-- Notifications Dropdown -->
        <div class="dropdown mr-3">
            <button class="btn btn-link position-relative" type="button" id="notificationDropdown" data-toggle="dropdown">
                <i class="fas fa-bell fa-lg text-dark"></i>
                @if(isset($parent) && $parent->unread_notification_count > 0)
                    <span class="badge badge-danger position-absolute" style="top: -5px; right: -5px; font-size: 10px;">
                        {{ $parent->unread_notification_count }}
                    </span>
                @endif
            </button>
            <div class="dropdown-menu dropdown-menu-right" style="width: 300px; max-height: 400px; overflow-y: auto;">
                <h6 class="dropdown-header">Notifications</h6>
                @if(isset($parent) && $parent->unreadNotifications()->count() > 0)
                    @foreach($parent->unreadNotifications()->limit(5)->get() as $notification)
                        <a href="{{ $notification->action_url ?? '#' }}" class="dropdown-item" onclick="markNotificationRead({{ $notification->id }})">
                            <small class="text-muted">{{ $notification->created_at->diffForHumans() }}</small>
                            <p class="mb-0"><strong>{{ $notification->title }}</strong></p>
                            <small>{{ Str::limit($notification->message, 50) }}</small>
                        </a>
                        <div class="dropdown-divider"></div>
                    @endforeach
                    <a href="{{ route('parent.notifications') }}" class="dropdown-item text-center text-primary">
                        View All Notifications
                    </a>
                @else
                    <div class="dropdown-item text-center text-muted">
                        No new notifications
                    </div>
                @endif
            </div>
        </div>
        
        <!-- User Profile Dropdown -->
        <div class="dropdown">
            <button class="btn btn-link dropdown-toggle" type="button" id="userDropdown" data-toggle="dropdown">
                <img src="{{ Auth::user()->image ? asset(Auth::user()->image) : asset('public/demo/user/user.jpg') }}" 
                     alt="Profile" class="rounded-circle" width="35" height="35">
                <span class="ml-2">{{ Auth::user()->name }}</span>
            </button>
            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="{{ route('parent.profile') }}">
                    <i class="fas fa-user mr-2"></i> My Profile
                </a>
                <a class="dropdown-item" href="{{ route('parent.change-password') }}">
                    <i class="fas fa-lock mr-2"></i> Change Password
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="{{ route('parent.logout') }}" 
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>
    </div>
</div>

