<div class="parent-sidebar" style="width: 260px;">
    <div class="p-4">
        <h4 class="text-white mb-4">
            <i class="fas fa-users"></i> Parent Portal
        </h4>
    </div>
    
    <nav class="nav flex-column">
        <a href="{{ route('parent.dashboard') }}" class="nav-link {{ request()->routeIs('parent.dashboard') ? 'active' : '' }}">
            <i class="fas fa-home mr-2"></i> Dashboard
        </a>
        
        <a href="{{ route('parent.children.index') }}" class="nav-link {{ request()->routeIs('parent.children.*') ? 'active' : '' }}">
            <i class="fas fa-child mr-2"></i> My Children
        </a>
        
        <a href="{{ route('parent.courses.index') }}" class="nav-link {{ request()->routeIs('parent.courses.*') ? 'active' : '' }}">
            <i class="fas fa-book mr-2"></i> Courses
        </a>
        
        <a href="{{ route('parent.reports.index') }}" class="nav-link {{ request()->routeIs('parent.reports.*') ? 'active' : '' }}">
            <i class="fas fa-chart-line mr-2"></i> Reports & Progress
        </a>
        
        <a href="{{ route('parent.payment.history') }}" class="nav-link {{ request()->routeIs('parent.payment.*') ? 'active' : '' }}">
            <i class="fas fa-credit-card mr-2"></i> Payments
        </a>
        
        <a href="{{ route('parent.notifications') }}" class="nav-link {{ request()->routeIs('parent.notifications') ? 'active' : '' }}">
            <i class="fas fa-bell mr-2"></i> Notifications
            @if(isset($parent) && $parent->unread_notification_count > 0)
                <span class="badge badge-danger ml-2">{{ $parent->unread_notification_count }}</span>
            @endif
        </a>
        
        <hr class="bg-light mx-3">
        
        <a href="{{ route('parent.profile') }}" class="nav-link {{ request()->routeIs('parent.profile') ? 'active' : '' }}">
            <i class="fas fa-user mr-2"></i> My Profile
        </a>
        
        <a href="{{ route('parent.change-password') }}" class="nav-link {{ request()->routeIs('parent.change-password') ? 'active' : '' }}">
            <i class="fas fa-lock mr-2"></i> Change Password
        </a>
        
        <a href="{{ route('parent.logout') }}" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
        </a>
        
        <form id="logout-form" action="{{ route('parent.logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
    </nav>
</div>

