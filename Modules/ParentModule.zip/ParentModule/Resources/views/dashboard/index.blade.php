@extends('parentmodule::layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')
@section('page-subtitle', 'Overview of your children\'s education')

@section('content')
<div class="container-fluid">
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stat-card bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="mb-0">{{ $stats['total_children'] }}</h3>
                        <p class="mb-0">Total Children</p>
                    </div>
                    <i class="fas fa-child fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="stat-card bg-success text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="mb-0">${{ number_format($stats['total_payments'], 2) }}</h3>
                        <p class="mb-0">Total Paid</p>
                    </div>
                    <i class="fas fa-dollar-sign fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="stat-card bg-warning text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="mb-0">${{ number_format($stats['pending_payments'], 2) }}</h3>
                        <p class="mb-0">Pending Payments</p>
                    </div>
                    <i class="fas fa-clock fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="stat-card bg-info text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="mb-0">{{ $stats['unread_notifications'] }}</h3>
                        <p class="mb-0">New Notifications</p>
                    </div>
                    <i class="fas fa-bell fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Children Overview -->
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">My Children</h5>
                </div>
                <div class="card-body">
                    @if($childrenData && count($childrenData) > 0)
                        @foreach($childrenData as $data)
                            <div class="child-card">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="d-flex">
                                        <img src="{{ $data['student']->image ? asset($data['student']->image) : asset('public/demo/user/user.jpg') }}" 
                                             alt="{{ $data['student']->name }}" 
                                             class="rounded-circle mr-3" 
                                             width="60" 
                                             height="60">
                                        <div>
                                            <h6 class="mb-1">{{ $data['student']->name }}</h6>
                                            <small class="text-muted">
                                                <i class="fas fa-user-tag mr-1"></i> {{ ucfirst($data['relationship']) }}
                                            </small>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-envelope mr-1"></i> {{ $data['student']->email }}
                                            </small>
                                        </div>
                                    </div>
                                    <a href="{{ route('parent.children.show', $data['student']->id) }}" class="btn btn-sm btn-outline-primary">
                                        View Details
                                    </a>
                                </div>
                                
                                <div class="row mt-3">
                                    <div class="col-4 text-center">
                                        <h6 class="mb-0 text-primary">{{ $data['total_courses'] }}</h6>
                                        <small class="text-muted">Total Courses</small>
                                    </div>
                                    <div class="col-4 text-center">
                                        <h6 class="mb-0 text-success">{{ $data['completed_courses'] }}</h6>
                                        <small class="text-muted">Completed</small>
                                    </div>
                                    <div class="col-4 text-center">
                                        <h6 class="mb-0 text-warning">{{ $data['in_progress_courses'] }}</h6>
                                        <small class="text-muted">In Progress</small>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        
                        <div class="text-center mt-3">
                            <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus mr-2"></i> Add Another Child
                            </a>
                        </div>
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-child fa-4x text-muted mb-3"></i>
                            <h5>No Children Added Yet</h5>
                            <p class="text-muted">Start by adding your children to manage their education</p>
                            <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus mr-2"></i> Add Your First Child
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Recent Notifications -->
            <div class="card mb-3">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Recent Notifications</h6>
                    <a href="{{ route('parent.notifications') }}" class="btn btn-sm btn-link">View All</a>
                </div>
                <div class="card-body p-0">
                    @if($recentNotifications && $recentNotifications->count() > 0)
                        <div class="list-group list-group-flush">
                            @foreach($recentNotifications as $notification)
                                <a href="{{ $notification->action_url ?? '#' }}" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">{{ $notification->title }}</h6>
                                        <small>{{ $notification->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1 small">{{ Str::limit($notification->message, 80) }}</p>
                                    @if($notification->student)
                                        <small class="text-muted">{{ $notification->student->name }}</small>
                                    @endif
                                </a>
                            @endforeach
                        </div>
                    @else
                        <div class="text-center py-4">
                            <i class="fas fa-bell-slash fa-2x text-muted mb-2"></i>
                            <p class="text-muted mb-0">No notifications</p>
                        </div>
                    @endif
                </div>
            </div>
            
            <!-- Recent Payments -->
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Recent Payments</h6>
                    <a href="{{ route('parent.payment.history') }}" class="btn btn-sm btn-link">View All</a>
                </div>
                <div class="card-body p-0">
                    @if($recentPayments && $recentPayments->count() > 0)
                        <div class="list-group list-group-flush">
                            @foreach($recentPayments as $payment)
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">${{ number_format($payment->amount, 2) }}</h6>
                                        <span class="badge badge-{{ $payment->payment_status == 'completed' ? 'success' : 'warning' }}">
                                            {{ ucfirst($payment->payment_status) }}
                                        </span>
                                    </div>
                                    <p class="mb-1 small">{{ $payment->course->title ?? 'Course Payment' }}</p>
                                    <small class="text-muted">{{ $payment->student->name ?? 'Student' }} - {{ $payment->created_at->format('M d, Y') }}</small>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="text-center py-4">
                            <i class="fas fa-receipt fa-2x text-muted mb-2"></i>
                            <p class="text-muted mb-0">No payments yet</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

