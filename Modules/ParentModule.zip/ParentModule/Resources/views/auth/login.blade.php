@extends('parentmodule::layouts.guest')

@section('title', 'Parent Login')

@section('content')
<div class="auth-card">
    <div class="auth-header">
        <h3 class="mb-2">Parent Portal</h3>
        <p class="mb-0">Login to manage your children's education</p>
    </div>
    
    <div class="auth-body">
        <form method="POST" action="{{ route('parent.login.submit') }}">
            @csrf
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    </div>
                    <input type="email" 
                           class="form-control @error('email') is-invalid @enderror" 
                           id="email" 
                           name="email" 
                           value="{{ old('email') }}" 
                           required 
                           autofocus
                           placeholder="Enter your email">
                </div>
                @error('email')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input type="password" 
                           class="form-control @error('password') is-invalid @enderror" 
                           id="password" 
                           name="password" 
                           required
                           placeholder="Enter your password">
                </div>
                @error('password')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>
            
            <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="remember" name="remember">
                    <label class="custom-control-label" for="remember">Remember Me</label>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-sign-in-alt mr-2"></i> Login
            </button>
            
            <div class="text-center mt-3">
                <a href="{{ route('parent.forgot-password') }}" class="text-muted">
                    Forgot Password?
                </a>
            </div>
            
            <hr>
            
            <div class="text-center">
                <p class="mb-0">Don't have an account?</p>
                <a href="{{ route('parent.register') }}" class="btn btn-outline-primary btn-sm mt-2">
                    Register as Parent
                </a>
            </div>
        </form>
    </div>
</div>
@endsection

