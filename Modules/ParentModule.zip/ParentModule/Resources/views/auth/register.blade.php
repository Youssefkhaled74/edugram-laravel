@extends('parentmodule::layouts.guest')

@section('title', 'Parent Registration')

@section('content')
<div class="auth-card">
    <div class="auth-header">
        <h3 class="mb-2">Parent Registration</h3>
        <p class="mb-0">Create an account to manage your children's education</p>
    </div>
    
    <div class="auth-body">
        <form method="POST" action="{{ route('parent.register.submit') }}">
            @csrf
            
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" 
                       class="form-control @error('name') is-invalid @enderror" 
                       id="name" 
                       name="name" 
                       value="{{ old('name') }}" 
                       required
                       placeholder="Enter your full name">
                @error('name')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" 
                               class="form-control @error('email') is-invalid @enderror" 
                               id="email" 
                               name="email" 
                               value="{{ old('email') }}" 
                               required
                               placeholder="your@email.com">
                        @error('email')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" 
                               class="form-control @error('phone') is-invalid @enderror" 
                               id="phone" 
                               name="phone" 
                               value="{{ old('phone') }}"
                               placeholder="+1234567890">
                        @error('phone')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="password">Password *</label>
                        <input type="password" 
                               class="form-control @error('password') is-invalid @enderror" 
                               id="password" 
                               name="password" 
                               required
                               placeholder="Min 8 characters">
                        @error('password')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="password_confirmation">Confirm Password *</label>
                        <input type="password" 
                               class="form-control" 
                               id="password_confirmation" 
                               name="password_confirmation" 
                               required
                               placeholder="Re-enter password">
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="national_id">National ID</label>
                <input type="text" 
                       class="form-control @error('national_id') is-invalid @enderror" 
                       id="national_id" 
                       name="national_id" 
                       value="{{ old('national_id') }}"
                       placeholder="Your national ID number">
                @error('national_id')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="occupation">Occupation</label>
                        <input type="text" 
                               class="form-control" 
                               id="occupation" 
                               name="occupation" 
                               value="{{ old('occupation') }}"
                               placeholder="Your occupation">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="workplace">Workplace</label>
                        <input type="text" 
                               class="form-control" 
                               id="workplace" 
                               name="workplace" 
                               value="{{ old('workplace') }}"
                               placeholder="Your workplace">
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="address">Address</label>
                <textarea class="form-control" 
                          id="address" 
                          name="address" 
                          rows="2"
                          placeholder="Your address">{{ old('address') }}</textarea>
            </div>
            
            <h6 class="mt-4 mb-3">Emergency Contact</h6>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="emergency_contact_name">Contact Name</label>
                        <input type="text" 
                               class="form-control" 
                               id="emergency_contact_name" 
                               name="emergency_contact_name" 
                               value="{{ old('emergency_contact_name') }}"
                               placeholder="Emergency contact name">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="emergency_contact">Contact Phone</label>
                        <input type="text" 
                               class="form-control" 
                               id="emergency_contact" 
                               name="emergency_contact" 
                               value="{{ old('emergency_contact') }}"
                               placeholder="Emergency contact phone">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-user-plus mr-2"></i> Register
            </button>
            
            <hr>
            
            <div class="text-center">
                <p class="mb-0">Already have an account?</p>
                <a href="{{ route('parent.login') }}" class="btn btn-outline-primary btn-sm mt-2">
                    Login Here
                </a>
            </div>
        </form>
    </div>
</div>
@endsection

