@extends('parentmodule::layouts.app')

@section('title', 'Courses')
@section('page-title', 'Children\'s Courses')
@section('page-subtitle', 'View all enrolled courses')

@section('content')
<div class="container-fluid">
    <!-- Filter by Child -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="{{ route('parent.courses.index') }}" method="GET" class="form-inline">
                <label class="mr-2">Filter by Child:</label>
                <select name="child_id" class="form-control mr-2" onchange="this.form.submit()">
                    <option value="">All Children</option>
                    @foreach($children as $child)
                        <option value="{{ $child->id }}" {{ $selectedChildId == $child->id ? 'selected' : '' }}>
                            {{ $child->name }}
                        </option>
                    @endforeach
                </select>
            </form>
        </div>
    </div>
    
    <!-- Courses Grid -->
    @if($enrollments && $enrollments->count() > 0)
        <div class="row">
            @foreach($enrollments as $enrollment)
                @if($enrollment->course)
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="{{ $enrollment->course->image ? asset($enrollment->course->image) : asset('public/demo/course.jpg') }}" 
                                 class="card-img-top" 
                                 alt="{{ $enrollment->course->title }}"
                                 style="height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title">{{ $enrollment->course->title }}</h5>
                                
                                @if(isset($enrollment->user))
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-user mr-1"></i> <strong>Student:</strong> {{ $enrollment->user->name }}
                                    </p>
                                @endif
                                
                                <p class="text-muted mb-2">
                                    <i class="fas fa-user-tie mr-1"></i> {{ $enrollment->course->user->name ?? 'Instructor' }}
                                </p>
                                
                                <p class="text-muted mb-2">
                                    <i class="fas fa-folder mr-1"></i> {{ $enrollment->course->category->name ?? 'Category' }}
                                </p>
                                
                                <div class="mb-3">
                                    <small class="text-muted">Progress</small>
                                    <div class="progress" style="height: 20px;">
                                        @php
                                            $progress = $enrollment->course->loginUserTotalPercentage ?? 0;
                                        @endphp
                                        <div class="progress-bar {{ $progress >= 100 ? 'bg-success' : 'bg-primary' }}" 
                                             role="progressbar" 
                                             style="width: {{ $progress }}%">
                                            {{ round($progress) }}%
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge badge-{{ $enrollment->status ? 'success' : 'secondary' }}">
                                        {{ $enrollment->status ? 'Active' : 'Inactive' }}
                                    </span>
                                    <small class="text-muted">
                                        Enrolled: {{ $enrollment->created_at->format('M d, Y') }}
                                    </small>
                                </div>
                            </div>
                            <div class="card-footer bg-white">
                                <a href="{{ route('parent.courses.show', [$enrollment->user_id, $enrollment->course_id]) }}" 
                                   class="btn btn-primary btn-block">
                                    <i class="fas fa-eye mr-2"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            {{ $enrollments->links() }}
        </div>
    @else
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-book fa-4x text-muted mb-3"></i>
                <h5>No Courses Found</h5>
                <p class="text-muted">Your children haven't enrolled in any courses yet</p>
                @if($children && $children->count() > 0)
                    <a href="{{ route('parent.courses.available', $children->first()->id) }}" class="btn btn-primary">
                        <i class="fas fa-search mr-2"></i> Browse Available Courses
                    </a>
                @endif
            </div>
        </div>
    @endif
</div>
@endsection

