@extends('parentmodule::layouts.app')

@section('title', 'Reports & Progress')
@section('page-title', 'Reports & Progress')
@section('page-subtitle', 'Track your children\'s academic performance')

@section('content')
<div class="container-fluid">
    @if($childrenReports && count($childrenReports) > 0)
        <div class="row">
            @foreach($childrenReports as $report)
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header bg-primary text-white">
                            <div class="d-flex align-items-center">
                                <img src="{{ $report['student']->image ? asset($report['student']->image) : asset('public/demo/user/user.jpg') }}" 
                                     alt="{{ $report['student']->name }}" 
                                     class="rounded-circle mr-3" 
                                     width="50" 
                                     height="50">
                                <div>
                                    <h5 class="mb-0">{{ $report['student']->name }}</h5>
                                    <small>{{ ucfirst($report['relationship']) }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Course Statistics -->
                            <h6 class="mb-3">Course Progress</h6>
                            <div class="row text-center mb-4">
                                <div class="col-4">
                                    <div class="stat-card bg-light p-3">
                                        <h4 class="mb-0 text-primary">{{ $report['total_courses'] }}</h4>
                                        <small class="text-muted">Total</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="stat-card bg-light p-3">
                                        <h4 class="mb-0 text-success">{{ $report['completed_courses'] }}</h4>
                                        <small class="text-muted">Completed</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="stat-card bg-light p-3">
                                        <h4 class="mb-0 text-warning">{{ $report['in_progress_courses'] }}</h4>
                                        <small class="text-muted">In Progress</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Quiz Statistics -->
                            <h6 class="mb-3">Quiz Performance</h6>
                            <div class="row text-center mb-4">
                                <div class="col-6">
                                    <div class="stat-card bg-light p-3">
                                        <h4 class="mb-0 text-info">{{ $report['total_quizzes'] }}</h4>
                                        <small class="text-muted">Quizzes Taken</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="stat-card bg-light p-3">
                                        <h4 class="mb-0 text-success">{{ $report['average_score'] }}%</h4>
                                        <small class="text-muted">Avg Score</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Certificates -->
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <i class="fas fa-certificate text-warning fa-2x"></i>
                                    <span class="ml-2"><strong>{{ $report['certificates'] }}</strong> Certificates Earned</span>
                                </div>
                            </div>
                            
                            <!-- Recent Activity -->
                            @if($report['recent_activity'])
                                <div class="text-muted small">
                                    <i class="fas fa-clock mr-1"></i> Last active: {{ $report['recent_activity']->diffForHumans() }}
                                </div>
                            @endif
                        </div>
                        <div class="card-footer bg-white">
                            <div class="btn-group btn-group-sm w-100">
                                <a href="{{ route('parent.reports.child', $report['student']->id) }}" class="btn btn-primary">
                                    <i class="fas fa-chart-line mr-1"></i> Detailed Report
                                </a>
                                <a href="{{ route('parent.reports.quiz-results', $report['student']->id) }}" class="btn btn-info">
                                    <i class="fas fa-question-circle mr-1"></i> Quiz Results
                                </a>
                                <a href="{{ route('parent.reports.certificates', $report['student']->id) }}" class="btn btn-warning">
                                    <i class="fas fa-certificate mr-1"></i> Certificates
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-chart-line fa-4x text-muted mb-3"></i>
                <h5>No Reports Available</h5>
                <p class="text-muted">Add children to view their progress reports</p>
                <a href="{{ route('parent.children.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus mr-2"></i> Add Child
                </a>
            </div>
        </div>
    @endif
</div>
@endsection

