@extends('parentmodule::layouts.app')

@section('title', 'Add Child')
@section('page-title', 'Add Child')
@section('page-subtitle', 'Link or create a student account')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Add Child Account</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('parent.children.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="form-group">
                            <label>Request Type *</label>
                            <div class="custom-control custom-radio">
                                <input type="radio" 
                                       id="link_existing" 
                                       name="request_type" 
                                       class="custom-control-input" 
                                       value="link_existing" 
                                       {{ old('request_type', 'link_existing') == 'link_existing' ? 'checked' : '' }}
                                       onchange="toggleRequestType()">
                                <label class="custom-control-label" for="link_existing">
                                    Link to Existing Student Account
                                </label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" 
                                       id="create_new" 
                                       name="request_type" 
                                       class="custom-control-input" 
                                       value="create_new" 
                                       {{ old('request_type') == 'create_new' ? 'checked' : '' }}
                                       onchange="toggleRequestType()">
                                <label class="custom-control-label" for="create_new">
                                    Request to Create New Student Account
                                </label>
                            </div>
                        </div>
                        
                        <div id="existing_student_fields">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle mr-2"></i>
                                Enter the email address of your child's existing student account. An admin will verify and approve the link.
                            </div>
                            
                            <div class="form-group">
                                <label for="student_email">Student Email Address *</label>
                                <input type="email" 
                                       class="form-control @error('student_email') is-invalid @enderror" 
                                       id="student_email" 
                                       name="student_email" 
                                       value="{{ old('student_email') }}"
                                       placeholder="student@example.com">
                                @error('student_email')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="student_name">Student Full Name *</label>
                            <input type="text" 
                                   class="form-control @error('student_name') is-invalid @enderror" 
                                   id="student_name" 
                                   name="student_name" 
                                   value="{{ old('student_name') }}"
                                   required
                                   placeholder="Enter student's full name">
                            @error('student_name')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="student_dob">Date of Birth</label>
                                    <input type="date" 
                                           class="form-control @error('student_dob') is-invalid @enderror" 
                                           id="student_dob" 
                                           name="student_dob" 
                                           value="{{ old('student_dob') }}">
                                    @error('student_dob')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="student_national_id">Student National ID</label>
                                    <input type="text" 
                                           class="form-control @error('student_national_id') is-invalid @enderror" 
                                           id="student_national_id" 
                                           name="student_national_id" 
                                           value="{{ old('student_national_id') }}"
                                           placeholder="Student's national ID">
                                    @error('student_national_id')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="relationship_type">Your Relationship to Student *</label>
                            <select class="form-control @error('relationship_type') is-invalid @enderror" 
                                    id="relationship_type" 
                                    name="relationship_type" 
                                    required>
                                <option value="">Select Relationship</option>
                                <option value="father" {{ old('relationship_type') == 'father' ? 'selected' : '' }}>Father</option>
                                <option value="mother" {{ old('relationship_type') == 'mother' ? 'selected' : '' }}>Mother</option>
                                <option value="guardian" {{ old('relationship_type') == 'guardian' ? 'selected' : '' }}>Legal Guardian</option>
                                <option value="grandfather" {{ old('relationship_type') == 'grandfather' ? 'selected' : '' }}>Grandfather</option>
                                <option value="grandmother" {{ old('relationship_type') == 'grandmother' ? 'selected' : '' }}>Grandmother</option>
                                <option value="uncle" {{ old('relationship_type') == 'uncle' ? 'selected' : '' }}>Uncle</option>
                                <option value="aunt" {{ old('relationship_type') == 'aunt' ? 'selected' : '' }}>Aunt</option>
                                <option value="sibling" {{ old('relationship_type') == 'sibling' ? 'selected' : '' }}>Sibling</option>
                                <option value="other" {{ old('relationship_type') == 'other' ? 'selected' : '' }}>Other</option>
                            </select>
                            @error('relationship_type')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        
                        <div class="form-group">
                            <label for="supporting_documents">Supporting Documents (Optional)</label>
                            <input type="file" 
                                   class="form-control-file @error('supporting_documents.*') is-invalid @enderror" 
                                   id="supporting_documents" 
                                   name="supporting_documents[]" 
                                   multiple
                                   accept=".pdf,.jpg,.jpeg,.png">
                            <small class="form-text text-muted">
                                Upload documents to verify your relationship (Birth certificate, ID, etc.). Max 5MB per file.
                            </small>
                            @error('supporting_documents.*')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            <strong>Note:</strong> Your request will be reviewed by an administrator before approval. You will be notified once approved.
                        </div>
                        
                        <div class="form-group mb-0">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane mr-2"></i> Submit Request
                            </button>
                            <a href="{{ route('parent.children.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times mr-2"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function toggleRequestType() {
    const requestType = document.querySelector('input[name="request_type"]:checked').value;
    const existingFields = document.getElementById('existing_student_fields');
    const emailField = document.getElementById('student_email');
    
    if (requestType === 'link_existing') {
        existingFields.style.display = 'block';
        emailField.required = true;
    } else {
        existingFields.style.display = 'none';
        emailField.required = false;
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    toggleRequestType();
});
</script>
@endpush
@endsection

