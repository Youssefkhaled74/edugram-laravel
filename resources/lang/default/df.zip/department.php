<?php

return [
    'Department' => 'Department',
];
