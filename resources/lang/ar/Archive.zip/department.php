<?php

return [
    'Department' => 'القسم',
];
