<?php
return [
"Department" => "Departamento",
];