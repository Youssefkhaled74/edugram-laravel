<?php
return [
"Department" => "Abteilung",
];